IMPORTANT! READ ME FIRST!

In order to view this project properly you must import the database schema in the file DATABASE.sql into your own database. Please note that you are responsible for the database name, username, password and host.

Then you must open "config/settings.php" and change the values of the constants to match your database credentials.

Then you must open "templates/core/header.html", find "<base href="http://localhost/" />" on line 4 and change the value of the "href" attribute to the url you will be viewing the project from. For example, if you will be viewing the project from "http://localhost/Fancentr" that should be the value. This is to ensure that all images and stylesheets are imported correctly.

You should be able to register normally but below are two users you can log in as. Please note that there is no admin user.

Email: sunnefa_lind@hotmail.com
Password: 1234

Email: shannen.sekaya@gmail.com
Password: 1234

Regards,
Sunnefa